Program: Q2toQ3T.exe V 0.82
Description: A utility that allows you to convert most smallish Quake 2 maps to run with Q3Test.
Requirements: Win98, Win95. I'm guessing it will not work with WinNT (sorry, it might, I don't know!)
Author: Mastaba
e-mail: mastabaprime@hotmail.com

Use: Unzip it where ever you like, it don't matter to me. Then run it.
Carefully follow the few (if any) prompts that appear.

V0.82 Fixed: Misaligned textures are much better now. (for some reason, liquids still look bad)
      Fixed: A rather massive memory leak
      Fixed: Save As defaults to [Q3Path]\baseq3\maps
      Fixed: Program remembers [Q3Path] & [Q2Path]
      Fixed: Program searches for pak files outside of baseq2
      Added: Default texture and default silence in instance of missing resource

V0.81 Fixed: Lightmap vectors are nearly perfect now! Thanks Niclas! I couldn't have got that fixed without
	your help. I bow down before you. :)

V0.80 Original Release

Known Bugs: 
	Bug: Currently, the program only looks for pak files in baseq2. If you convert a map
	that has resources in a pak file that is not in baseq2, then the missing resource
	will show up as white if the resource was a texture, or you will hear it as a buzzing sound
	if the resource was a sound.
	Solution: In the next release I will have more robust pak file enumeration.

	Bug: A few faces that have a weird slant to them get converted incorrectly.
	Solution: Either ignore the HOM or avoid converting maps that have a bunch of slanted faces.

	Bug?: You convert a map, but Q3Test fails to run it with a Hunk_AllocLow error.
	Solution: Umm, sounds like Q3Test ran out of memory. Stay away from really big levels.

	Bug: You convert a map, but when you run it you see patches of white everywhere.
	Solution: Make sure you have the full retail version of Quake 2 before you convert a map.
		Also be sure to select the Quake 2 directory when asked.

	Bug: You convert a map, but when you run it you hear annoying buzzing sounds.
	Solution: Make sure you have the full retail version of Quake 2 before you convert a map.
		Also be sure to select the Quake 2 directory when asked.

	Bug: I failed to remove monster entities (forgot all about monsters in there)
	Solution: Level should still play normally, the file is just a little bigger than it needs
		to be.

	Bug: Quite often the z co-ordinate of player and deathmatch start positions and teleport destinations
	will need manual adjustments to get the player unstuck from the floor.
	Solution: For now, use Q3Wumpass to manually change the z values. Use small increments of 10 or 20
		at a time.
	
	Bug: Expansion pack levels are not supported. They may or may not work. They will require
	a lot of manually editing however.
	Solution: I have no plans to support them at this time.

	Bug: Some teleport models may not be visible since Q3Test does not have them.
	Solution: This will be fixed in the next iteration of this convertor.

	Bug: I'm sure there are more.
	Solution: Patience, grasshopper.
	
	Bug: I try to run the covertor but it won't
	Solution: Could be you need a more recent 
So in general, it works very well for deathmatch levels designed for about 8 people and which
have few if any highly slanted faces.


NOTE: Q3Test is not Quake 2! Many elements of Quake 2 are not present in Q3Test.
For example: Hidden doors, and ladders do not work. It appears that there is no need for them
in Q3A.

STANDARD DISCLAIMER: As with any beta software, things can and often do go wrong. Usually thats
	just a harmless crash, however,	I've only run this program on my computer, a K6-2 300
	with 128MB. So I of course take no responsibility for any consequential damage to your
	computer or data that results from the use of this program.


Have fun!!!


