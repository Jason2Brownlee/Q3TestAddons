//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MD3View.rc
//
#define IDS_FILESTRING                  1
#define IDS_RAWFILEFILTER               2
#define TAG_MENU_ID                     3
#define IDS_SKINFILEFILTER              3
#define IDS_UPPERANIM                   4
#define IDS_MD3FILEFILTER               4
#define IDS_LOWERANIM                   5
#define IDS_SEQFILTER                   5
#define IDR_MENU1                       101
#define IDI_APP                         102
#define IDR_ACCELERATOR1                105
#define ID_FILE_EXIT                    40002
#define ID_ABOUT                        40003
#define ID_VIEW_WIREFRAME               40004
#define ID_VIEW_FLATSHADED              40005
#define ID_VIEW_TEXTURED                40006
#define ID_VIEW_TEXTUREDSHADED          40007
#define ID_VIEW_NEAREST                 40008
#define ID_VIEW_UNFILTEREDTEXTURE       40010
#define ID_VIEW_FILTEREDTEXTURE         40011
#define ID_VIEW_FLIPFACESIDES           40012
#define ID_ANIMATION_SLOWER             40013
#define ID_ANIMATION_FASTER             40014
#define ID_ANIMATION_STOP               40015
#define ID_ANIMATION_START              40016
#define ID_ANIMATION_REWIND             40017
#define ID_ANIMATION_INTERPOLATE        40018
#define ID_FILE_EXPORTTORAW             40019
#define ID_FILE_IMPORTSKIN              40020
#define ID_VIEW_REFRESHTEXTURE          40021
#define ID_FRAME_UP                     40022
#define ID_FRAME_DW                     40023
#define ID_VIEW_LOADEDSTUFF             40024
#define ID_LOD0                         40025
#define ID_LOD1                         40026
#define ID_LOD2                         40027
#define ID_FACE_INCANIM                 40028
#define ID_FACE_DECANIM                 40029
#define ID_FACE_RESANIM                 40030
#define ID_VIEWAXIS                     40031
#define ID_VIEWLOWERANIM_INC            40032
#define ID_VIEWLOWERANIM_DEC            40033
#define ID_VIEWLOWERANIM_LOCK           40034
#define ID_VIEWUPPERANIM_INC            40035
#define ID_VIEWUPPERANIM_DEC            40036
#define ID_VIEWUPPERANIM_LOCK           40037
#define ID_FILE_SAVE_MD3                40039
#define ID_FILE_IMPORTMULTISEQ          40040
#define ID_VIEWALPHA                    40041
#define ID_SCREENSHOT_CLIPBOARD         40042
#define ID_SCREENSHOT_FILE              40043
#define ID_VIEW_COLOURPICKER            40044
#define ID_VIEW_FOVTOGGLE               40045
#define ID_FILE_SAVE_G2                 40046
#define ID_PICMIP0                      40047
#define ID_PICMIP1                      40048
#define ID_PICMIP2                      40049
#define ID_PICMIP3                      40050
#define ID_PICMIP4                      40051
#define ID_PICMIP5                      40052
#define ID_PICMIP6                      40053
#define ID_PICMIP7                      40054
#define ID_VIEWPOS_RESET                40055
#define ID_VIEW_TEXTUREDWIREFRAME       40056
#define ID_VIEW_BOUNDSTOGGLE            40057
#define ID_FILE_SAVE_G2_PERFECT         40058
#define ID_TAG_START                    50000
#define ID_MENUITEMS_UPPERANIMS         60000
#define ID_MENUITEMS_LOWERANIMS         61000
#define ID_MENUITEMS_NEXT               62000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40059
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
