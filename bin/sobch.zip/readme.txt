                   High Resolution Crosshair Pak
                   by Russell "Essobie" O'Henly
                     essobie@planetquake.com

1. Place the pak file of your choice in your quake2/baseq2/ directory. Use the one
   that coincides with your Quake 2 resolution for best results.

2. Rename that pak file to the next highest pak file number in your baseq2 directory.
   For Example, if  you have pak1, pak2, pak3, and pak5 already, rename this new pak
   to pak6.pak, and you are good to go.

   Another example is if you currently use a pak9.pak file.  If you do, and you would
   like to easily override the crosshairs in that pak file, just rename your pak9 to
   a lower pak number, such as pak8, and then rename your new crosshair pak file to
   one above it.

   WARNING: You cannot have paks higher than 9, but you CAN skip pak numbers (in Quake 2).

3. Pick your favorite Crosshair of the 3 from that pak by typeing in "crosshair x" where
   "x" is 1-3.... or use some of these idea for crosshair use:

Sensitivity Alias
=================
Want to be a bit more accurate with that railgun or that chaingun?  Try a sensitivity
switching alias to go between "fast sensitivity" and "slow sensitivity".  Then use your
new crosshairs to toggle between the two... and use the third crosshair for a zoom toggle!

Try this alias to go along with your new crosshairs included in this zip file:

// Begin
set highsens 8.5
set lowsens 2.5
alias senshigh "set sensitivity $highsens; alias sensswitch senslow; crosshair 1"
alias senslow "set sensitivity $lowsens; alias sensswitch senshigh; crosshair 2"
senshigh
set fovnorm 110
set fovzoom 30
alias zoomin "set fov $fovzoom; alias zoomswitch zoomout; senslow; crosshair 3"
alias zoomout "set fov $fovnorm; alias zoomswitch zoomin; senshigh"
alias zoomswitch zoomout
zoomout

bind MOUSE2 sensswitch
bind CTRL zoomswitch
// End

Weapon Switching Crosshairs
===========================
This one isn't really an alias... more like just some added text to your weapon
selection bindings.  You can group your weapons into types... like "Explosive",
"Hitscan" and "Accuracy".  Try these binds:

// Begin
bind 1                  "use blaster; crosshair 3"
bind 2                  "use shotgun; crosshair 3"
bind 3                  "use super shotgun; crosshair 2"
bind 4                  "use machinegun; crosshair 2"
bind 5                  "use chaingun; crosshair 2"
bind 6                  "use grenade launcher; crosshair 1"
bind 7                  "use rocket launcher; crosshair 1"
bind 8                  "use hyperblaster; crosshair 3"
bind 9                  "use railgun; crosshair 3"
bind 0                  "use bfg10k; crosshair 1"

bind g                  "use grenades"
bind z                  "use hyperblaster; crosshair 3"
bind x                  "use railgun; crosshair 3"
bind c                  "use grenade launcher; crosshair 1"
bind v                  "use rocket launcher; crosshair 1"
bind b                  "use bfg10k; crosshair 1"
// End

Have fun!
-Essobie

