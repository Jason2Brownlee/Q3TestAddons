Description:	These maps are modifications to id maps created with the help of Mastaba's Wumpass utility that convert all weapons on the map to rail guns, and all ammo to slugs.  Power ups were also modified in some maps so as to provide more balance with the weapon changes.

Installation:	To use these maps, unzip the file into your baseq3 folder.  This will place the .pk3 file in the proper place.

Notes:
Bots will not currently work on these maps, since there is no way currently to create .aas files.  Once id releases the map tools, this might change.

These maps were editted by Depleted Uranium for our servers.

DU1: 63.73.156.10:27960 - Teamplay/CTF
DU2: 63.73.156.11:27960 - FFA
DU3: Private - PLEASE don't bother asking for the password, we don't give it out!


If you want to distribute these maps in any way, please include all text files.  These maps were not created by me, but were created by id.  I only modified the weapons and power ups.

Credits:

Brother.Syclone - for actually hacking the maps and doing all the real work to get things working.
Mastaba - for his Q3Wumpass program that let us hack the maps in the first place.
id Software - for releasing quite possibly the last game that many of us will ever end up playing (DAMN you Id! We need sleep dammit!)
Tim Willits - for being the mapping king.
Christian Antkow - for being another mapping king.
Paul Jaquays - for being yet another mapping king.

The House of Depleted Uranium servers have stats up and running at http://63.73.156.10/ (soon to be moved to planetq3.net!) as well as info about the House members and the House itself.  If you have no idea what I'm talking about when I say "House", come on by and find out! ;)

-Syclone
rail_me@hotmail.com