11/16/1999
================================================================
Title                   : Quake3 Demo Restricetd Mode Crack
Filename                : q3dcrk.exe
Version                 : 1.0
Description             : Disables restricetd mode in Quake 3 Demo Test 
				: Version 1.09
================================================================

Extract the q3dcrk.exe to your Q3DemoTEST directory and run it.

It will patch your quake3.exe file and rename the demoq3 directory 
to baseq3.

Notes
=====
id seems to have added a twist to the file system in the demo. Even
with the patch applied, it will not load maps that are not in pk3 files.
This may be a permanent limitation or it may be related to the 
"PRE_RELEASE_DEMO hack" Carmack mentions in his plan.

As far as I can tell, other files can load fine from the baseq3 directory 
(not in pk3 files). I have personaly verified models and demos only though.

In any event, to use external maps, zip them up in a pk3 file of your own. 
Feel free to zip up the file with an ordanary zip utility (such as WinZip).
Make sure the maps are in a maps folder inside the zip file. As promised by
a recent plan update from Carmack, you can use any name for pk3 files, not 
ust pak0-9 only. The only requirement is that the file have a pk3 extension.

Old converted maps will not work. The version number at minimum requires
chaning from 45 to 46 although I do not know if the format has changed.





