                     Essobie's Nifty Green Q3Test Crosshair
                          by Russell "Essobie" O'Henly

WARNING: Use this thing at your own risk.  It works, but I'm not responcible
for your unsupported Q3test blowing up because of this one single .tga file.

Place the "crosshair.tga" in your q3test/baseq3/gfx/2d/ directory.

Start up Q3test.  Set your "crosshairsize" by typing in the console:

crosshairsize x

... where "x" is how big you want it.  I like 40, but feel free to experiment.

If you have any questions about how to alter crosshairs yourself, here's some
things to help you figure it out:

1)  Use Photoshop 4.0 or later to edit the .tga file's "Alpha Channel".  If you
don't know what an Alpha Channel is, read in Photoshop's help.

2)  Anything that is black in the Alpha Channel will not show up in the final
crosshair, regardless of what you have in the other 3 channels.

3)  Shades of grey in the Alpha Channel tell q3test how opaque to make anything
in the other channels.  This allows you to make fading and anti-aliasing
effects in your crosshair.  Nifty stuff.

4)  You cannot increase the size of the canvas from 32x32 pixels, and you MUST
save your .tga crosshair as a 32bit image for it to work.

Any other questions, you'll have to figure out for yourself.  Good luck.

-Essobie
http://www.planetquake.com/ra2io/

