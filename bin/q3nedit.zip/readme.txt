+--------------------------+
|Quake 3 Name Creater 1.1a |
+--------------------------+--------------------------------------+
| http://www.capecod.net/~sschneid/q3nc                           |
| By: phazer (phazer@evatac.com)                                  |
|                                                                 |
| [Installation]: To get the name scripts to work with Q3TEST,    |
| you have to follow these instructions.                          |
|                                                                 |
| 1. Rename your demoq3 directory to baseq3.                      |
| 2. Place the scripts in your baseq3 directory.                  |
| 3. To execute them in Q3TEST, type: exec <scriptname>.          |
|                                                                 |
| [Disclaimer]: If this software happens to harm your computer in |
| any way, we are not responsible.  You use the software at your  |
| own risk.                                                       |
+--------------------------------------------------[5/21/99]------+
EOF
