09/26/1999
============================================..............
Title                   : estaFUN
Buildtime               : one funny Week:-)
Editor                  : Qeradiant
Filename                : estaFUN.bsp
Author                  : estaPHAN from LechValley Gibba�z
Email Address           : estaphan@gmx.de
compatible Q3Test	: version 1.08
============================================..............

* Play Information *

Single Player           : No
Cooperative             : No
Deathmatch              : Yes, Q3test Vers. 1.08
Difficulty Settings     : No



Installation 

In order to get this map to work, all you need is to disable restricted 
mode in Q3Test. To do this, simply get a crack and apply it to your Q3Test.


AND HAVE FUN!!







