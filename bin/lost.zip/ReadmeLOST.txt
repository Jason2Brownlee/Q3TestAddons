19/16/1999
============================================..............
Title                   : Lost
Buildtime               : a really cool Time:-)
Editor                  : Qeradiant
Filename                : lost.bsp
Author                  : estaPHAN from LechValley Gibba�z
HomePage                : www.quakershome.de (LG PAGE!!)
Email Address           : estaphan@gmx.de
compatible Q3Test	: version 1.08
============================================..............

* Play Information *

Single Player           : No
Cooperative             : No
Team DM                 : Mhhh??
Deathmatch              : 1:1 or FFA max. 4 Players!
Difficulty Settings     : No



Installation 

In order to get this map to work, all you need is to disable restricted 
mode in Q3Test. To do this, simply get a crack and apply it to your Q3Test.


AND HAVE FUN!!







