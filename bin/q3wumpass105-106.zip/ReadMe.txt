Q3Wumpass (aka I couldn't think of a title :p)
Works with Q3Test v1.05 & v1.06 maps

What is it?
It is a program that facilitates the hacking of existing bsp files.
It only allows you to insert, remove, or change items, weapons, and other classes.
IT DOES NOT LET YOU CHANGE THE GEOMETRY!

How do you use it?
First you click Export, and choose the bsp file you want to hack.
Then you choose a name for the saved entity lump. It ends up being a text file.
Then you can edit that text file with Wordpad (Notepad doesn't like the naked LF).
Do not put any blank lines or extraneous lines. Then you save your file.

After you've saved the file restart Q3Wumpass and click Import.
Then select the text file to import.
Then select the bsp file to merge it with (usually the same one you exported from).
Then select the name for the new bsp to be saved as.
DO NOT SELECT THE SAME BSP IN THE MERGE AND SAVE AS DIALOG BOXES!!!
IT WON'T WORK THAT WAY!!!!!
THE BSP FILE YOU ARE SAVING AS MUST BE DIFFERENT FROM THE ONE YOU ARE MERGING WITH!

This way if you goof (or God forbid Q3Wumpass goofs), you'll still have the original bsp.

Who made Q3Wumpass?
That would be me, Mastaba.

LEGAL MUMBO JUMBO:
Yada yada yada and I take no responsibility for anything that should occur in the use
of this here program named Q3Wumpass. USE AT YOUR OWN RISK!!

And if you use this proggy to convert a bsp and it should happen to leak out,
I wouldn't mind some kind of acknowledgement.
Laterz Doodz.

