******NOTE: I take no responsiblity if any damage occurs as a result of these files********

I made this update for win32 using some files from the ihv and a modified q3test1/2. Basically the q3test2 now has the plasma gun and grenade launcher plus their ammo. The q3test1 map includes a grenade launcher in the map plus ammo. This zip file contains all the sounds, md3's etc that you'll need. As an added bonus, I've added the crosshair pack that's available at www.planetquake.com/ra2io as well as a new hit sound.  Enjoy!


I. Installation Instructions

	A. The first thing you need to do is rename C:\q3test\demoq3 to C:\q3test\baseq3.
	
	B. Now rename pak0.pk3 found in C:\q3test\baseq3 to pak0.zip
		1. Once the file has been renamed to pak0.zip, unzip it to C:\q3test\baseq3
		2. You may delete the pak0.zip file after you have done the above.
	
	C. Open up the win32 update zip file that you downloaded.
		1. Extract product.txt to C:\q3test\baseq3
		2. Extract crosshairs.zip to a temp directory
		3. Extract the rest of the files to C:\ 	
	
	D. You're done!
		1. If you did everything written above correctly, you should
		now be able to use the maps by typing, map q3test1b or map q3test2b
		in the console. Enjoy!



II. Some problems you may encounter and their answers.
	
	A. Default.cfg Issue
		1. You may get an error saying, "default.cfg found". You need to have
		this file in the /baseq3 dir in order to solve this problem.
	
	B. Textures not showing up on ammo items and receiving missing tga errors
		1. You unzipped the update incorrectly. Make sure you unzip
		it to C:\  not C:\q3test. 




-Zip created by [TLN]5150 Joker
-Thanks to my programmer friend who wishes to stay anonymous for his awesome programming that enabled us to make q3test3.
-This zip file may be freely distributed so long as its contents are NOT changed. Please keep all map names and file paths intact otherwise there'll be a lot of confusion when
trying to join servers w/diff map names.

*******************************************************************************************