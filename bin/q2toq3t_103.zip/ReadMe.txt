Program: Q2toQ3T.exe V 1.03
Description: A utility that allows you to convert most smallish Quake 2 maps to run with Q3Test.
Requirements: Win98, Win95. I've been told it works with WinNT 4 (SP5 ?)
Author: Mastaba
e-mail: mastabaprime@hotmail.com

Use: Unzip it where ever you like, it don't matter to me. Then run it.
Carefully follow the few (if any) prompts that appear.

V1.03 Fixed?: For native mode conversions, occaisonally (almost randomly) some textures               would be scaled incorrectly. This appears to be fixed, stress on appears.

V1.02 Fixed: For native mode conversions, a case-sensitive (oops!) search in the shader code has              been changed to case-insensitive. This fixes a good number mis-scaled shaders.

V1.01 Fixed: Lightvectors are good again.
      Added: FullBright option, useful for testing native conversions of unlit maps.
      Added: Simple Door Logic option, causes the converter to convert doors directly without
	     attempting to fix triggers that control them.
      Added: By compromise with a collection Q2 mappers, Normal mode conversions are tagged as
             being conversions. See Note below.
      Added: In normal conversions, monster entities are now removed.
      Added: In native mode conversions, monsterclip brushes are converted into 'missleclip'
	     brushes. Used to prevent shooting the sky. A small map is included to show you how 	     to use it.

V0.99 Fixed: Lightmap coordinates are now much better.
	     (Laymens terms: Most geometric, aka sharp, shadows are gone)
      Fixed: Most doors and secret doors should work now.
      Fixed: Stuck in ceiling bug (e.g. in dmc_dm6) introduced in V0.90 appears to be fixed.
      Fixed: Single player entities are removed i.e. if(spawnflags & 2048).
      Added: Options dialog
      Added: RGB Gamma, Brightness, and Contrast controls for wal->tga (and optionally lightmap)
	     conversion. Use the rewrite option to overwrite a preexisting tga.
      Added: Q3Native mode conversions. Explained below.
      Added: A few command line options. Explained below.
    Tweaked: User interface is slightly modified.
 Slightly broken: Lightvectors get screwed up occaisionally on nonaxial faces. I figure this
		  is a bug I put in when I fixed the lightmap coordinates. Hopefully I fix it 		  	  soon.

V0.91 Added: Water and slime textures in the level are now substituted.
      Added: Shader for qdm\teleport texture

V0.90 Fixed: HOM errors are hopefully eliminated. (Thanks again Niclas!)
      Fixed: Stuck in the floor bug shouldn't occur anymore
      Added: Q3 Lava texture is substituted for most Q2 lava textures
      
V0.82 Fixed: Misaligned textures are much better now. (for some reason, liquids still look bad)
      Fixed: A rather massive memory leak
      Fixed: Save As defaults to [Q3Path]\baseq3\maps
      Fixed: Program remembers [Q3Path] & [Q2Path]
      Fixed: Program searches for pak files outside of baseq2
      Added: Default texture and default silence in instance of missing resource

V0.81 Fixed: Lightmap vectors are nearly perfect now! Thanks Niclas! I couldn't have got that 		     fixed without your help. I bow down before you. :)

V0.80 Original Release

Known Bugs: 
	Bug: Some doors and buttons either don't work, or act strange
	Solution: This is probably due to Q3Test not fully supporting those
	entities, or supporting them differently.

	Bug: Default sound added in V0.82 does not always work
	Solution: Copy the sound over yer self, or wait till I debug it.

	Bug?: You convert a map, but Q3Test fails to run it with a Hunk_AllocLow error.
	Solution: Umm, sounds like Q3Test ran out of memory. Stay away from really big levels.

	Bug: You convert a map, but when you run it you see patches of white everywhere.
	Solution: Make sure you have the full retail version of Quake 2 before you convert a map.
		Also be sure to select the Quake 2 directory when asked.

	Bug: You convert a map, but when you run it you hear annoying buzzing sounds.
	Solution: Make sure you have the full retail version of Quake 2 before you convert a map.
		Also be sure to select the Quake 2 directory when asked.

	Bug: Expansion pack levels are not supported. They may or may not work. They will require
	a lot of manually editing however.
	Solution: I have no plans to support them at this time.

	Bug: I'm sure there are more.
	Solution: Patience, grasshopper.
	

So in general, it works very well for deathmatch levels designed for about 8 people.


NOTE: Q3Test is not Quake 2! Many elements of Quake 2 are not present in Q3Test.
For example: Hidden doors, and ladders do not work. It appears that there is no need for them
in Q3A.

Normal vs Q3Native mode:
Use Nomal mode when you are converting a preexisting map originally designed and intended for Quake 2 play.
Use Q3Native mode if you are converting a hybrid Quake 2-Q3Test map. This is a Quake 2 map designed with Q3Test's textures and entities. Note, in this mode the converter doesn't touch the entity lump so you can put anything you like in there. Also the converter correctly handles shaders and tga's, i.e. a texture entry in the texinfo lump can reference either a tga or a shader. If it references a shader, then the converter uses the texture in the qer_editorimage line to determine its dimensions. If the shader does not have a qer_editorimage line, then the converter will look for a tga of the same name. If that fails then it will assume a size of 64x64. One note however, experimentation has brought me to the conclusion that Q3Test's shader parser is incomplete or crippled. Also several lines appear to be used by make utilities E.g. there are several different lavahell shaders, each one being a different brightness. I suspect an updated qrad3 could be used to read the shaders and relight the bsp before converting it to a q3test bsp, to take advantage of those multiple shaders of varying brightness.

Command line options:
/q3tex		:starts the converter in Q3Native mode.
/primary dirname	:causes the converter to first look in [Q2Path]\[dirname] for Q2 			resources before looking in other [Q2Path] subdirectories
/adjust n	:changes the way the converter adjusts the player spawnpoint heights
		n is a number
		0 - do not adjust
		1 - use constant offset method (like in V0.90)
		2 - best face method (default), this method tries to find the floor directly
		    below the spawnpoint and then it sets the height relative to it.
                    Note: In some circumstances this method can put the spawnpoint in a very
		    different position. I.e. if the spawnpoint was originally closer to the
		    ceiling than to the floor so that the newly spawned player would fall a 
		    significant height, this method screws that up. Also if the floor below the 		    spawnpoint is highly slanted, it could position the spawnpoint a little high.
/dir dirname	:causes the converter to put Quake 2 texture resources in 					[Q3Path]\baseq3\textures\quake2\dirname and sounds in
		[Q3Path]\baseq3\sounds\quake2\dirname
/debug		:do not use, it doesn't do anything useful for you.    
	 
/daikatana	:causes the converter to convert .wals as daikatana style .wal textures


Note: Some Q2 map authors would like you to obtain their permission before distributing unauthorized conversions of their maps.

STANDARD DISCLAIMER: As with any beta software, things can and often do go wrong. Usually thats
	just a harmless crash, however,	I've only run this program on my computer, a K6-2 300
	with 128MB. So I of course take no responsibility for any consequential damage to your
	computer or data that results from the use of this program.


Have fun!!!


