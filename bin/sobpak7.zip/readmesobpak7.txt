                         Essobie's SOBPak7.pk3
                         =====================

                             Terms of Use
                             ------------
Buy unzipping the contents of the zip file you downloaded from our page into
your Quake 3: Arena baseq3 directory, you agree to not hold me liable for any
damages these graphic alterations cause you, your computer system, or any
children you may parent in the future.

THIS IS NOT A CHEAT PAK!!!  THERE ARE NO ALTERATIONS TO SMOKE TRAILS, SKINS,
MODELS, NOR ANY OTHER THING THAT I CONCIDER CHEATING.  Don't ask for it.

                       Installation Instructions:
                       --------------------------
1) Unzip the contents of this zip file into your "baseq3" folder.

2) Join a server that either has this pak installed, or is running with
   "Pure Server" turned off (sv_pure 0).  Fear not... if the server does
   not have this pak, you will still be able to play there... just without
   looking at the contents of this pak.

   For single player, or listen servers run from your system, you will be
   able to see the contents of this media pak perfectly.

   It is for this reason that I strongly urge you to pimp this pak as much
   as possible, and get as many server admins to install it.  This way we
   can have cool new graphics, and still be free from those that would make
   a pak like this for the purpose of cheating.

3) See the bottom of this file for tips on getting the most out of this
   package.


                        Files Changed from Pak0
                        -----------------------
All Crosshairs
All Heads Up Display Numbers
Both Console graphics
Lightning Gun Effect Graphics
Railgun Effect Core Graphic
Teamplay Triangle (Green instead of Yellow)
Chat Balloon


                               Credits
                               -------
                      Russell "Essobie" O'Henly
                       essobie@planetquake.com

           This and all sorts of other stuff can be found on
                   Rocket Arena 2: Inside and Out
                  http://www.planetquake.com/ra2io



                           Tips for SOBPak7
                           ----------------

1) Crosshairs 1-6 are regular crosshair size.  These should look normal on
   most people's screens.  7-10 on the other hand are larger than normal,
   128x128 to be exact.  For these crosshairs to look correct, bring down
   the console and type the following command:

      /cg_crosshairSize 128

   This will increase the displayed size of the crosshair file.  The default
   setting for that command (if you want to go back to normal) is:

      /cg_crosshairSize 24

2)  A couple of the last crosshairs are specifically for sniping with the
    Railgun.  If you would like to use them for ONLY the Railgun, try binding
    your normal weapon selection keys to include a crosshair and crosshairsize
    command.  Pick your "normalcrosshair" and your "snipercrosshair" and change
    the first two lines.  Then put the whole thing in your configuration.

//  Begin
set normalcrosshair "cg_drawCrosshair 4; cg_crosshairSize 24"
set snipercrosshair "cg_drawCrosshair 10; cg_crosshairSize 128"

bind 1 "weapon 1; vstr normalcrosshair" // BFG
bind 2 "weapon 2; vstr normalcrosshair" // Gauntlet
bind 3 "weapon 3; vstr normalcrosshair" // Shotgun
bind 4 "weapon 4; vstr normalcrosshair" // Machinegun
bind 5 "weapon 5; vstr normalcrosshair" // LightningGun

bind 6 "weapon 6; vstr normalcrosshair" // GrenadeLauncher
bind 7 "weapon 7; vstr snipercrosshair" // Railgun
bind 8 "weapon 8; vstr normalcrosshair" // PlasmaGun
bind 9 "weapon 9; vstr normalcrosshair" // BFG
bind 0 "weapon 10; vstr normalcrosshair" // Grapple
// End

3)  If you are REALLY nuts about the sniper idea, how about just have a
    sniper crosshair when you are zoomed in, regardless of what weapon
    you are using?  To do that, use a zoom script and simply put in the
    appropriate commands to change the crosshairs back and forth.  An
    example is what I have in my configuration (don't forget to change
    the bindings at the bottom!!!):

// Zoomcycle Begin
set zoomin "+zoom; cg_drawCrosshair 10; cg_crosshairSize 128; set zoomswitch vstr zoomout"
set zoomout "-zoom; cg_drawCrosshair 4; cg_crosshairSize 24; set zoomswitch vstr zoomin"
set zoomswitch vstr zoomin

set zoomcycle80 "set cg_zoomfov 80; echo Zoom Set to FOV 80; set zoomcycle vstr zoomcycle65"
set zoomcycle65 "set cg_zoomfov 65; echo Zoom Set to FOV 65; set zoomcycle vstr zoomcycle45"
set zoomcycle45 "set cg_zoomfov 45; echo Zoom Set to FOV 45; set zoomcycle vstr zoomcycle25"
set zoomcycle25 "set cg_zoomfov 25; echo Zoom Set to FOV 25; set zoomcycle vstr zoomcycle80"
set cg_zoomfov 45
set zoomcycle vstr zoomcycle65

bind [yourkey] vstr zoomcycle
bind [yourkey] vstr zoomswitch
// End