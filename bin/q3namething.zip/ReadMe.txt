
|
| Q3NameThing by pfgSoft 
| Version 1.0 - Released May 17, 1999 
|

Send comments, bug reports, suggestions, etc. to painfield@spyring.com
Visit pfgSoft at http://pfg.8m.com

INTRODUCTION
------------

With Q3Test returns the ability to create "Fun Names".  "Fun Names" are player names that use the full set of symbols available in Q3Test (including three alphabets) as well as a variety of colors.  Q3NameThing is a utility to allow for the easy creation of these "Fun Names". 

INSTRUCTIONS
------------

Q3NameThing is easy to use.  Simply point and click with your mouse to "type" your new name.  When you are satisfied with the name you've created, click the "Generate" button to add it to the Q3Test configuration.  NOTE: Q3NameThing will attempt to find the Q3Test folder, however you may be prompted to help locate the folder.  


NOTE FOR GAMESPY USERS
----------------------

When GameSpy is used to launch a game of Q3Test, it sends a command to change the player name to the name in the current GameSpy player profile.  This will overwrite the name created by Q3NameThing.  The Q3NameThing GameSpy fix should correct this problem.  Make sure that "GameSpy Fix" is selected before clicking the "Generate" button.


>>> Send comments, bug reports, suggestions, etc. to painfield@spyring.com

Copyright 1999 pfgSoft

pfgSoft assumes no liability for any damages, loss of productivity, death, destruction, chaos, etc. that results from the use or misuse of this product.  


