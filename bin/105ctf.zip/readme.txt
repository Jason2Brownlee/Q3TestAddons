=MASTER= CTF Ver 1.05 Final!

Whats New:

Contains New CTF Maps. masterctf4, masterctf5, masterctf6
Contains New Explosive CTF MAP BFG ARENA!
Contains New Sky
Contains New Flags
Contains New BFG Look
Contains New BFG Muzzle Flash
Contains New Enhanced Hud Display
Contains New Flight Rune Look
Contains New Icon Display
Contains New Crosshair
Contains New Console Background
Contains New Rail Effect

Includes:

BFG, Grenade Launcher, Grapple, Haste Rune, Flight Rune, Regen Rune, 
Enviroment Rune. 

Fixes:

Fixed the problem with flags never returning when dropped into a void. 
Fixed BFG muzzle flash. Added sound to the 3 maps. Changed flight rune. 
Fixed flag carrier color. (they were reversed) Converted the "id" pointer into a crosshair.
Changed the Console Background. Fixed not hearing BFG hum. 
Changed the Respawning times on runes. And more, to many to remember.

Buggs:

Can't seem to get weapons lit in the masterctf4 map. Flags have a "BLACK" edge. I'm
gonna change them but will have to do for now. There's probably more but to tired 
to think straight.

Instalation:

0. Put the Enclosed crack in your Q3 Directory
1. Run the Crack.
2. Rename your demoq3 to baseq3
3. Rename your Q3 Directory to quake3
4. Should look like this now   ?:\quake3\baseq3
5. Run the CTF105.exe Thats it your done!
6. "HINT" runs better if you unpack the pak9.pk3 instead of playing out of the pak.
     You can do this by using winzip to extract it to ?:\quake3\baseq3

CREDITS:

Icons, some map layout in masterctf6, grapple skin, Thanks to RiGoRmOrTiS.
Grapple, BFG, Grenade Launcher Thanks to Bob The Monkey.
Special thanks to the artist who made the maps "VQ3" and "MQ3" If I knew who
you were I'd give a Credit to your work. Great Maps! Thank You!

Unless "Buggy" This should be the final release. I've included the code for the maps for
anyone getting ambitious.  =MASTER=


 
      




