Railgun Fix from Dr.DooM

Stick this in your config...

r_railSegmentLength "16"
r_railCoreWidth "2"
r_railWidth "32"
cg_railTrailTime "1200"
color "7"

