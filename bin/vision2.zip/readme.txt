Vision Pak 2.  v1.0  5/24/99

The Vision pak is a compilation of public pak files for 
the Q3test Demo made for Win 32.  

The purpose of these files is to improve your vision while
firing weapons.  Smoke trails from the Rocket Launcher are 
reduced to barely visible.  That big smoke puff from the 
shotgun is gone.  Muzzle flash from the shotgun and machine gun
are greatly reduced.

The smoke puff graphics were altered by frankos@lynxus.com and by
Essobie - essobie@planetquake.com of the Rocket Arena 2 Strategy 
Page, RA2 In & Out - http://www.planetquake.com/ra2io/
The shotgun graphic was altered by Cerberus -aka ernie_dodds@iname.com
The machine gun graphic was altered by rjdriver@aol.com

PLASMA GUN MUZZLE FLASH:

There is no new graphic for this. To improve your vision even more, 
delete the plasma_flash.md3 file from your pak0.pk3.  
This will remove the muzzleflash from the Plasma Gun. Make a backup 
copy of the pak0.pk3 file, in case you don't care for the results. 

RAIL GUN TRACERS:

Also, a good config to reduce the Railgun tracers was done by James
Long, JamesLong@home.com.  Create an autoexec.cfg file inside the 
baseq3 folder and put the following lines in it.

 
seta r_railCoreWidth "2"
seta r_railWidth "32"
seta cg_railTrailTime "100"
seta r_railSegmentLength "64"


INSTALLATION:

1.  Rename the demoq3 folder to baseq3.
2.  Place the pak6.pk3 file in the baseq3 folder.


UNINSTALL:

1.  Remove the pak6.pk3 file from the base q3 folder, and the game
will revert to it's orginal graphics.

FILES IN THIS ZIP:

machineg.txt
shotgun.txt
smokepfs.txt
f_machingun.tga
f_shotgun.tga
smokepuff.tga
smokepuff2.tga
smokepuffragepro.tga
readme.txt

Happy Fragging................
rjdriver@aol.com
5/24/99
