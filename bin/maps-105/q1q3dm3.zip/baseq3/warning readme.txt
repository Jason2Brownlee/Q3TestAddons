Map: The Abandoned Base: - Quake1 to Quake3 Conversion
Author: SpoonFed
Legal: This map may not be used until id authorizes the use of custom maps under the provisions of the EULA. 


