Unzip this file into \baseq3 directory, preserving the directories it contains.

You should now have \baseq3\models\players\visor.
in here are all the addtional skins.

Currently Q3Test doesn't pick these extra skins up, so to change to
one type the following at the q3 console

model visor/<skinname>

where <skinname> is one of the following:

Cyan
EED
Lore
metalice
Militant
quadmaniac
visogro


for example to use the quadmaniac skin, you would type:

model visor/quadmaniac


--

Jaruzel@dircon.co.uk
